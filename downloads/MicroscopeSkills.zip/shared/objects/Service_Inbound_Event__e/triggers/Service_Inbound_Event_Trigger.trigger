trigger Service_Inbound_Event_Trigger on Service_Inbound_Event__e (after insert) {

    // configured to pick up limited events, see the related platformEventSubscriberConfig
    List<ServiceSerialize.SerializedInvocationStructure> listInputs = ServiceAsync.getSerializedInvocationList(Trigger.New);
    ServiceAsync.asyncInvokeService(listInputs);    

}